import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;
import java.util.HashMap;

def Message processData(Message message) {
    //Read body as String (Parser in general would be the better choice, but 
    //since we want to reuse the body multiple times, a String is easier here.)
    def body = message.getBody(java.lang.String) as String;
    
    //Parse Telegram message from body
    def slurper = new JsonSlurper()
    def bodyObj = slurper.parseText(body)
    //Read chat.id (=user id of the Telegram user)
    message.setProperty("msgInChatId", bodyObj.message.chat.id)
    //Read chat message the user send to the bot
    message.setProperty("msgInText", bodyObj.message.text != null ? bodyObj.message.text : "")

    //Get LogFactory and create MPL attachment with original Telegram messageLog
    //This is not necessary, but really gives some nice insights
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        messageLog.addAttachmentAsString("TELEGRAM_EVENT", body, "application/json");
    }
    
    return message;
}