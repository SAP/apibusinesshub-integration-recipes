import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;

def Message processData(Message message) 
{
      def a = ITApiFactory.getApi(ValueMappingApi.class, null);
      def mappedValue = a.getMappedValue("Fruit", "US", "Apple", "Fruit", "Germany");
      def messageLog = messageLogFactory.getMessageLog(message);
	  messageLog.setStringProperty("Mapped Value", mappedValue);
      return message;
}

