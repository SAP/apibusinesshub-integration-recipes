/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.ITApi;
import com.sap.it.api.mapping.ValueMappingApi;

def Message processData(Message message) {
    //Body 

    def valueMapApi         = ITApiFactory.getApi(ValueMappingApi.class, null);
    def map                 = message.getProperties();
    
    def sourceAgency        = map.get("sourceAgency");
    def sourceIdentifier    = map.get("sourceIdentifier");
    def sourceValue         = map.get("sourceValue");
    def targetAgency        = map.get("targetAgency");
    def targetIdentifier    = map.get("targetIdentifier");

    def value = valueMapApi.getMappedValue(sourceAgency, sourceIdentifier, sourceValue, targetAgency, targetIdentifier);

    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null ) {
        if ( value != null ){
        messageLog.addAttachmentAsString("Output : Target Value Mapping is  ", value, "text/plain");
        }
        else{
            messageLog.addAttachmentAsString("Output : Target Value Mapping is  ", "Not Found", "text/plain");
        }
    }
    return message;
}